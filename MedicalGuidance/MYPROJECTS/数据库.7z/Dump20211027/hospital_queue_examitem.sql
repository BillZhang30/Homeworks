CREATE DATABASE  IF NOT EXISTS `hospital_queue` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `hospital_queue`;
-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: hospital_queue
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `examitem`
--

DROP TABLE IF EXISTS `examitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `examitem` (
  `ItemID` char(7) NOT NULL,
  `ExamName` char(20) NOT NULL,
  `Pre-Costraint` char(7) DEFAULT NULL,
  `Restriction` char(7) DEFAULT NULL,
  `InstrumentID` char(7) DEFAULT NULL,
  `InstrumentName` char(15) DEFAULT NULL,
  `Time` smallint DEFAULT NULL,
  PRIMARY KEY (`ItemID`,`ExamName`),
  KEY `insid_fk_idx` (`InstrumentID`),
  KEY `restr_fk_idx` (`Restriction`),
  KEY `preconstr_fk_idx` (`Pre-Costraint`),
  CONSTRAINT `insid_fk` FOREIGN KEY (`InstrumentID`) REFERENCES `instrumentinfo` (`IID`),
  CONSTRAINT `preconstr_fk` FOREIGN KEY (`Pre-Costraint`) REFERENCES `examitem` (`ItemID`),
  CONSTRAINT `restr_fk` FOREIGN KEY (`Restriction`) REFERENCES `restriction` (`RID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `examitem`
--

LOCK TABLES `examitem` WRITE;
/*!40000 ALTER TABLE `examitem` DISABLE KEYS */;
INSERT INTO `examitem` VALUES ('100','常规体格检查',NULL,NULL,'CG01','常规检查设备',2),('101','外科',NULL,NULL,'WK01','外科检查设备',4),('102','血压',NULL,NULL,'XY01','血压计',3),('103','内科',NULL,NULL,'NK01','内科检查设备',3),('110','耳鼻喉',NULL,NULL,'EB01','耳鼻喉检查包',15),('111','眼科常规',NULL,NULL,'LX01','裂隙灯显微镜',10),('112','眼底','111',NULL,'YD01','眼底检测仪',8),('113','视力',NULL,NULL,'SL01','视力表',7),('120','血常规',NULL,'9001','XQ01','血球仪',10),('121','血生化','120','9001','XS01','血液生化分析仪',10),('122','尿常规',NULL,NULL,'NY01','尿液干化学分析仪',7),('123','便常规',NULL,NULL,'DB01','大便常规分析仪',6),('130','胸透',NULL,'9002','XG01','X光机',15),('131','心电图',NULL,NULL,'XD01','心电图机',12),('132','腹部彩超',NULL,NULL,'CC01','彩超机',14),('201','妇科常规',NULL,NULL,'FK01','妇科常规设备',10),('202','乳腺X线摄影',NULL,'9002','XG02','X光机',15),('203','宫颈刮片TCT',NULL,NULL,'GJ01','TCT采样器',8),('204','妇科B超',NULL,NULL,'BC01','B超机',16),('301','前列腺B超',NULL,NULL,'BC02','B超机',16);
/*!40000 ALTER TABLE `examitem` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-10-27 14:25:47
