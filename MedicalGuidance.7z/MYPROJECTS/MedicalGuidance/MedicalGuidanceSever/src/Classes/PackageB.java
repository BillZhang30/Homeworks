package Classes;

import java.util.ArrayList;

public class PackageB extends Package{
    public PackageB(ArrayList<String> itemId) {
        super(itemId);
    }
    public PackageB(){}
}
