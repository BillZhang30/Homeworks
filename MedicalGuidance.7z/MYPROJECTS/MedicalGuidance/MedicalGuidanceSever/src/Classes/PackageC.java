package Classes;

import java.util.ArrayList;

public class PackageC extends Package{
    public PackageC(ArrayList<String> itemId) {
        super(itemId);
    }
    public PackageC(){}
}
