package Classes;

import java.util.ArrayList;

public class PackageA extends Package{

    public PackageA(ArrayList<String> itemId) {
        super(itemId);
    }
    public PackageA(){}
}
