package Classes;

import java.util.ArrayList;

public class PackageD extends Package{

    public PackageD(ArrayList<String> itemId) {
        super(itemId);
    }
    public PackageD(){}
}
